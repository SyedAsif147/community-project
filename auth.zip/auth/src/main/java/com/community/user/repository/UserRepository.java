package com.community.user.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.community.user.entity.UserEntity;

@Repository
@Transactional
public interface UserRepository extends JpaRepository<UserEntity, Integer>{

	@Query(value="select * from user_entity where user_id=:userId",nativeQuery = true)
	UserEntity findByUserId(@Param("userId")Integer userId);

	@Query(value="select * from user_entity where user_email=:userEmail",nativeQuery = true)
	UserEntity findByUserEmail(@Param("userEmail")String userEmail);

	@Query(value="select * from user_entity where active=:active",nativeQuery = true)
	List<UserEntity> findByUserDetails(@Param("active")Boolean active);

	@Query(value="select * from user_entity",nativeQuery = true)
	List<UserEntity> findByAllUser();

}
