package com.community.user.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.community.auth.utils.JSONUtil;
import com.community.user.VO.UserVo;
import com.community.user.constant.UserConstant;
import com.community.user.service.UserService;
import com.google.gson.Gson;

import net.sf.json.JSONObject;


@RestController
@RequestMapping(value=UserConstant.USER)
public class UserController {
	
	static Gson gson=new Gson();
	@Autowired
	UserService userService;
	
	@GetMapping(value=UserConstant.GET_USER_DETAILS)
	public ResponseEntity<JSONObject>getUserDetails(@RequestParam(value="userId",required = false) Integer userId,@RequestParam(value="userEmail",required=false) String userEmail){
		JSONObject userDetails=null;
		try {
			UserVo userVo=userService.getUserDetails(userId,userEmail);
			JSONObject jsonObject=new JSONObject();
			jsonObject.put("UserDetails", JSONObject.fromObject(userVo));
			userDetails=jsonObject;
		}catch (Exception e) {
			// TODO: handle exception
		}
		return new ResponseEntity<>(userDetails,HttpStatus.OK);
		
	}
	
	@GetMapping(value=UserConstant.GET_USER_DETAILS)
	public ResponseEntity<JSONObject>getAllUserDetails(@RequestParam(value="active",required = false) Boolean active){
		JSONObject userDetails=null;
		try {
			List<UserVo> userVo=userService.getAllUserDetails(active);
			JSONObject jsonObject=new JSONObject();
			jsonObject.put("UserAllDetails", JSONObject.fromObject(userVo));
			userDetails=jsonObject;
		}catch (Exception e) {
			// TODO: handle exception
		}
		return new ResponseEntity<>(userDetails,HttpStatus.OK);
		
	}
	
	@PostMapping(value=UserConstant.ADD_USER_DETAILS)
	public ResponseEntity<JSONObject>addUserDetails(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse ){
		JSONObject userDetails=null;
		try {
			String user=httpServletRequest.getParameter("user");
			if(StringUtils.isNotEmpty(user)) {
				UserVo userVo=(UserVo) JSONUtil.fromJson(user, UserVo.class);
				if(userVo.getUserEmail()!=null) {
					userService.addUserDetails(userVo);
				}
				
			}
			
		}catch (Exception e) {
			// TODO: handle exception
		}
		return new ResponseEntity<>(userDetails,HttpStatus.OK);
		
	}
	
	@PutMapping(value=UserConstant.UPDATE_USER_DETAILS)
	public ResponseEntity<JSONObject>updateUserDetails(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse ){
		JSONObject userDetails=null;
		try {
			String user=httpServletRequest.getParameter("user");
			if(StringUtils.isNotEmpty(user)) {
				UserVo userVo=(UserVo) JSONUtil.fromJson(user, UserVo.class);
				if(userVo.getUserEmail()!=null) {
					userService.updateUserDetails(userVo);
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		return new ResponseEntity<>(userDetails,HttpStatus.OK);
		
	}

}
