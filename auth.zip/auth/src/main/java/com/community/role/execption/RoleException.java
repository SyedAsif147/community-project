package com.community.role.execption;

public class RoleException {

}
