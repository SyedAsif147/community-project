package com.community.role.constant;

public class RoleConstant {
	public static final String ROLE="/role";
	public static final String GET_ROLE_ALL_DETAILS="/getallroledetails";
	public static final String GET_ROLE_DETAILS="/getroledetails";
	public static final String ADD_ROLE_DETAILS="/addroledetails";
	public static final String UPDATE_ROLE_DETAILS="/updateroledetails";
}
