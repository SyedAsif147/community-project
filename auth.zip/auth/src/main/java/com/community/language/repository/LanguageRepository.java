package com.community.language.repository;

public interface LanguageRepository {

}
