package com.community.language.constant;

public class LanguageConstant {

}
