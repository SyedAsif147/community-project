package com.community.language.execption;

public class LanguageException {

}
