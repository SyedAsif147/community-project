package com.community.language.service;

public interface LanguageService {

}
