package com.community.language.controller;

public class LanguageController {

}
