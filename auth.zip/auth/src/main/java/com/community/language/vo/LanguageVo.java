package com.community.language.vo;

import com.community.language.entity.LanguageEntity;

public class LanguageVo {
	private Integer languageId;

	private String languageName;

	public Integer getLanguageId() {
		return languageId;
	}

	public void setLanguageId(Integer languageId) {
		this.languageId = languageId;
	}

	public String getLanguageName() {
		return languageName;
	}

	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}
	
	LanguageEntity toLanguageEntity() {
		LanguageEntity languageEntity=new LanguageEntity();
		languageEntity.setLanguageName(this.getLanguageName());
		return languageEntity;
		
	}
}
