package com.community.language.service.serviceImpl;

import org.springframework.stereotype.Service;

import com.community.language.service.LanguageService;

@Service
public class LanguageServiceImpl implements LanguageService{

}
