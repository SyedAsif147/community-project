package com.community.auth.vo;

import lombok.Data;

@Data
public class UserVO {
    private Integer userId;
    private String userFName;
    private String userLName;
    private String userEmail;
    private String mobileNo;
    private String userPass;
    private Long userCreatedOn;
    private Boolean activeUser;
    private Integer userRoleId;
    private String userProfilePic;
    private Integer languageMasterId;
}