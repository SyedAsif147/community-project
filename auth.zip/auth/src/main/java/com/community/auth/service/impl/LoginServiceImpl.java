package com.community.auth.service.impl;

import com.community.auth.entites.UserMaster;
import com.community.auth.repos.UserMasterRepo;
import com.community.auth.service.LoginService;
import com.community.auth.utils.EncryptDecryptPassword;
import com.community.auth.vo.UserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.nio.charset.StandardCharsets;
import java.util.Optional;

@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    UserMasterRepo userMasterRepo;

    @Override
    public boolean validateUser(UserVO userVO) {
        boolean login = false;
        UserMaster userMaster = userMasterRepo.findByUserEmail(userVO.getUserEmail());
        if(!ObjectUtils.isEmpty(userMaster) && Optional.of(userMaster.getUserPass()).isPresent()){
            login = EncryptDecryptPassword.checkPassword(userVO.getUserPass(),userMaster.getUserPass());
        }
        return login;
    }
}
