package com.community.auth.entites;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "user_master")
@Data
public class UserMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Integer userId;
    @Column(name = "user_fname")
    private String userFName;
    @Column(name = "user_lname")
    private String userLName;
    @Column(name = "user_email")
    private String userEmail;
    @Column(name = "mobile_no")
    private String mobileNo;
    @Column(name = "user_pass")
    private String userPass;
    @Column(name = "user_created_on")
    private Long userCreatedOn;
    @Column(name = "active_user")
    private Boolean activeUser;
    @Column(name = "userrole_id")
    private Integer userRoleId;
    @Column(name = "user_profile_pic")
    private String userProfilePic;
    @Column(name = "language_master_id")
    private Integer languageMasterId;

}
