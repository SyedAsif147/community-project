package com.community.auth.entites;

public class LoginStatusHistory {
}
