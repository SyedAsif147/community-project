package com.community.auth.entites;

public class UserLoginHistory {
}
