package com.community.auth.service;

import com.community.auth.vo.UserVO;

public interface LoginService {
    boolean validateUser(UserVO userVO);
}
